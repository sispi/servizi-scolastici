package it.filippetti.sispi.repository;

import it.filippetti.sispi.model.RataLog;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RataLogRepository extends JpaRepository<RataLog, Long> {

}
