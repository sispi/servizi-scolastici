package it.filippetti.sispi.service;

public interface IseeConstants {
	public static final String STATO_BOZZA = "BOZZA";
	public static final String STATO_APPROVATO = "APPROVATO";
	public static final String STATO_NON_APPROVATO = "NON_APPROVATO";
}
