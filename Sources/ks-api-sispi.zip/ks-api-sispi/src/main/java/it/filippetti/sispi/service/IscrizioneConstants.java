package it.filippetti.sispi.service;

public interface IscrizioneConstants {
	public static final String ESITO_AMMESSO = "AMMESSO";
	public static final String CONFERMATA_ISCRIZIONE_SI = "C";
	public static final String NOTIFICATA_ISCRIZIONE_SI = "S";
	public static final Integer GIORNI_FREQUENZA_DEFAULT = 30;
}
