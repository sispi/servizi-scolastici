Vue.component('grid-editor', {
    props: [],

    created: function () {
        this.$options.template = "#editor";
    },
    mounted: function () {
    },
    data: function () {
    }
});


