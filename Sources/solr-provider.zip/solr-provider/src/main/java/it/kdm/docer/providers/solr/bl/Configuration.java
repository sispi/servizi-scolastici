package it.kdm.docer.providers.solr.bl;

/**
 * Created by microchip on 06/05/15.
 */
public class Configuration {
    public static class Keys {
        public static String ZK_HOST = "zkHost";
        public static String LOCATION = "location";
        //public static String USE_PASSWORD_MD5 = "use-password-md5";
        public static String SECRET = "secretKey";
    }


}