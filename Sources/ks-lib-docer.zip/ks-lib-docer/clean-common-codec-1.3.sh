#!/bin/sh
for f in `find -name *codec*1.3.jar`
do
	 rm "$f"
done
