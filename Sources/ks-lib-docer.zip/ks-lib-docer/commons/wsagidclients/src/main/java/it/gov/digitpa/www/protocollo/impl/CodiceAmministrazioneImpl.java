/*
 * XML Type:  CodiceAmministrazione
 * Namespace: http://www.digitPa.gov.it/protocollo/
 * Java type: it.gov.digitpa.www.protocollo.CodiceAmministrazione
 *
 * Automatically generated - do not modify.
 */
package it.gov.digitpa.www.protocollo.impl;
/**
 * An XML CodiceAmministrazione(@http://www.digitPa.gov.it/protocollo/).
 *
 * This is a complex type.
 */
public class CodiceAmministrazioneImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements it.gov.digitpa.www.protocollo.CodiceAmministrazione
{
    
    public CodiceAmministrazioneImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
