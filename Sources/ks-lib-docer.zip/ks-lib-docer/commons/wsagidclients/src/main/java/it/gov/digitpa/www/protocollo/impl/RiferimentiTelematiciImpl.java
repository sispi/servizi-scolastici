/*
 * XML Type:  RiferimentiTelematici
 * Namespace: http://www.digitPa.gov.it/protocollo/
 * Java type: it.gov.digitpa.www.protocollo.RiferimentiTelematici
 *
 * Automatically generated - do not modify.
 */
package it.gov.digitpa.www.protocollo.impl;
/**
 * An XML RiferimentiTelematici(@http://www.digitPa.gov.it/protocollo/).
 *
 * This is a complex type.
 */
public class RiferimentiTelematiciImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements it.gov.digitpa.www.protocollo.RiferimentiTelematici
{
    
    public RiferimentiTelematiciImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
