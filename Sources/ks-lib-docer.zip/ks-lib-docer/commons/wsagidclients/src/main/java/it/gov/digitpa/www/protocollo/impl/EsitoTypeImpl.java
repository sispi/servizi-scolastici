/*
 * XML Type:  esitoType
 * Namespace: http://www.digitPa.gov.it/protocollo/
 * Java type: it.gov.digitpa.www.protocollo.EsitoType
 *
 * Automatically generated - do not modify.
 */
package it.gov.digitpa.www.protocollo.impl;
/**
 * An XML esitoType(@http://www.digitPa.gov.it/protocollo/).
 *
 * This is an atomic type that is a restriction of it.gov.digitpa.www.protocollo.EsitoType.
 */
public class EsitoTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements it.gov.digitpa.www.protocollo.EsitoType
{
    
    public EsitoTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected EsitoTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
