/*
 * XML Type:  TipoProcedimento
 * Namespace: http://www.digitPa.gov.it/protocollo/
 * Java type: it.gov.digitpa.www.protocollo.TipoProcedimento
 *
 * Automatically generated - do not modify.
 */
package it.gov.digitpa.www.protocollo.impl;
/**
 * An XML TipoProcedimento(@http://www.digitPa.gov.it/protocollo/).
 *
 * This is a complex type.
 */
public class TipoProcedimentoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements it.gov.digitpa.www.protocollo.TipoProcedimento
{
    
    public TipoProcedimentoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
