/*
 * XML Type:  DataAvvio
 * Namespace: http://www.digitPa.gov.it/protocollo/
 * Java type: it.gov.digitpa.www.protocollo.DataAvvio
 *
 * Automatically generated - do not modify.
 */
package it.gov.digitpa.www.protocollo.impl;
/**
 * An XML DataAvvio(@http://www.digitPa.gov.it/protocollo/).
 *
 * This is a complex type.
 */
public class DataAvvioImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements it.gov.digitpa.www.protocollo.DataAvvio
{
    
    public DataAvvioImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
