/*
 * XML Type:  CodiceRegistro
 * Namespace: http://www.digitPa.gov.it/protocollo/
 * Java type: it.gov.digitpa.www.protocollo.CodiceRegistro
 *
 * Automatically generated - do not modify.
 */
package it.gov.digitpa.www.protocollo.impl;
/**
 * An XML CodiceRegistro(@http://www.digitPa.gov.it/protocollo/).
 *
 * This is a complex type.
 */
public class CodiceRegistroImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements it.gov.digitpa.www.protocollo.CodiceRegistro
{
    
    public CodiceRegistroImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
