/*
 * XML Type:  TipoDocumento
 * Namespace: http://www.digitPa.gov.it/protocollo/
 * Java type: it.gov.digitpa.www.protocollo.TipoDocumento
 *
 * Automatically generated - do not modify.
 */
package it.gov.digitpa.www.protocollo.impl;
/**
 * An XML TipoDocumento(@http://www.digitPa.gov.it/protocollo/).
 *
 * This is a complex type.
 */
public class TipoDocumentoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements it.gov.digitpa.www.protocollo.TipoDocumento
{
    
    public TipoDocumentoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
