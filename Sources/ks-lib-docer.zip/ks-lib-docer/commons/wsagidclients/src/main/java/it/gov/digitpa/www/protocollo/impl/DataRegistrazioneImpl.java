/*
 * XML Type:  DataRegistrazione
 * Namespace: http://www.digitPa.gov.it/protocollo/
 * Java type: it.gov.digitpa.www.protocollo.DataRegistrazione
 *
 * Automatically generated - do not modify.
 */
package it.gov.digitpa.www.protocollo.impl;
/**
 * An XML DataRegistrazione(@http://www.digitPa.gov.it/protocollo/).
 *
 * This is a complex type.
 */
public class DataRegistrazioneImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements it.gov.digitpa.www.protocollo.DataRegistrazione
{
    
    public DataRegistrazioneImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
