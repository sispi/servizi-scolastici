/*
 * XML Type:  CodiceAOO
 * Namespace: http://www.digitPa.gov.it/protocollo/
 * Java type: it.gov.digitpa.www.protocollo.CodiceAOO
 *
 * Automatically generated - do not modify.
 */
package it.gov.digitpa.www.protocollo.impl;
/**
 * An XML CodiceAOO(@http://www.digitPa.gov.it/protocollo/).
 *
 * This is a complex type.
 */
public class CodiceAOOImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements it.gov.digitpa.www.protocollo.CodiceAOO
{
    
    public CodiceAOOImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
