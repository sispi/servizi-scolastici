/*
 * XML Type:  Provvedimento
 * Namespace: http://www.digitPa.gov.it/protocollo/
 * Java type: it.gov.digitpa.www.protocollo.Provvedimento
 *
 * Automatically generated - do not modify.
 */
package it.gov.digitpa.www.protocollo.impl;
/**
 * An XML Provvedimento(@http://www.digitPa.gov.it/protocollo/).
 *
 * This is a complex type.
 */
public class ProvvedimentoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements it.gov.digitpa.www.protocollo.Provvedimento
{
    
    public ProvvedimentoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
