/*
 * XML Type:  TipoContestoProcedurale
 * Namespace: http://www.digitPa.gov.it/protocollo/
 * Java type: it.gov.digitpa.www.protocollo.TipoContestoProcedurale
 *
 * Automatically generated - do not modify.
 */
package it.gov.digitpa.www.protocollo.impl;
/**
 * An XML TipoContestoProcedurale(@http://www.digitPa.gov.it/protocollo/).
 *
 * This is a complex type.
 */
public class TipoContestoProceduraleImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements it.gov.digitpa.www.protocollo.TipoContestoProcedurale
{
    
    public TipoContestoProceduraleImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
