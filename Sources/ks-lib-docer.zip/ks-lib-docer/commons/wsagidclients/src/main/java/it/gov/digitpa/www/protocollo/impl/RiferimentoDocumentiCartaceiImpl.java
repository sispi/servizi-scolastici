/*
 * XML Type:  RiferimentoDocumentiCartacei
 * Namespace: http://www.digitPa.gov.it/protocollo/
 * Java type: it.gov.digitpa.www.protocollo.RiferimentoDocumentiCartacei
 *
 * Automatically generated - do not modify.
 */
package it.gov.digitpa.www.protocollo.impl;
/**
 * An XML RiferimentoDocumentiCartacei(@http://www.digitPa.gov.it/protocollo/).
 *
 * This is a complex type.
 */
public class RiferimentoDocumentiCartaceiImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements it.gov.digitpa.www.protocollo.RiferimentoDocumentiCartacei
{
    
    public RiferimentoDocumentiCartaceiImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
