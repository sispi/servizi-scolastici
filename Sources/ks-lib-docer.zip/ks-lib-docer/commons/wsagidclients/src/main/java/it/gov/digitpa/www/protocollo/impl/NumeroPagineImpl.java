/*
 * XML Type:  NumeroPagine
 * Namespace: http://www.digitPa.gov.it/protocollo/
 * Java type: it.gov.digitpa.www.protocollo.NumeroPagine
 *
 * Automatically generated - do not modify.
 */
package it.gov.digitpa.www.protocollo.impl;
/**
 * An XML NumeroPagine(@http://www.digitPa.gov.it/protocollo/).
 *
 * This is a complex type.
 */
public class NumeroPagineImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements it.gov.digitpa.www.protocollo.NumeroPagine
{
    
    public NumeroPagineImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
