/*
 * XML Type:  DataTermine
 * Namespace: http://www.digitPa.gov.it/protocollo/
 * Java type: it.gov.digitpa.www.protocollo.DataTermine
 *
 * Automatically generated - do not modify.
 */
package it.gov.digitpa.www.protocollo.impl;
/**
 * An XML DataTermine(@http://www.digitPa.gov.it/protocollo/).
 *
 * This is a complex type.
 */
public class DataTermineImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements it.gov.digitpa.www.protocollo.DataTermine
{
    
    public DataTermineImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
