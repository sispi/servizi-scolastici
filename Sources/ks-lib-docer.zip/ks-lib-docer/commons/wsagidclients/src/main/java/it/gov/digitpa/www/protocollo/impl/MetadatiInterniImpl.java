/*
 * XML Type:  MetadatiInterni
 * Namespace: http://www.digitPa.gov.it/protocollo/
 * Java type: it.gov.digitpa.www.protocollo.MetadatiInterni
 *
 * Automatically generated - do not modify.
 */
package it.gov.digitpa.www.protocollo.impl;
/**
 * An XML MetadatiInterni(@http://www.digitPa.gov.it/protocollo/).
 *
 * This is a complex type.
 */
public class MetadatiInterniImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements it.gov.digitpa.www.protocollo.MetadatiInterni
{
    
    public MetadatiInterniImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
