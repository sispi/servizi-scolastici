
/**
 * ProtocolloRicezioneEsitiServiceSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.6  Built on : Aug 30, 2011 (10:00:16 CEST)
 */
package it.gov.digitpa.www.protocollo;

/**
 * ProtocolloRicezioneEsitiServiceSkeleton java skeleton for the axisService
 */
public class ProtocolloRicezioneEsitiServiceSkeleton implements ProtocolloRicezioneEsitiServiceSkeletonInterface {


    /**
     * Auto generated method signature
     *
     * @param notifica0
     */

    public it.gov.digitpa.www.protocollo.EsitoConsegnaDocument ricezioneEsiti
    (
            it.gov.digitpa.www.protocollo.NotificaDocument notifica0
    ) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#ricezioneEsiti");
    }

}
    