
/**
 * ProtocolloRicezioneEsitiServiceSkeletonInterface.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.6  Built on : Aug 30, 2011 (10:00:16 CEST)
 */
    package it.gov.digitpa.www.protocollo;
    /**
     *  ProtocolloRicezioneEsitiServiceSkeletonInterface java skeleton interface for the axisService
     */
    public interface ProtocolloRicezioneEsitiServiceSkeletonInterface {
     
         
        /**
         * Auto generated method signature
         * 
                                    * @param notifica
         */

        
                public it.gov.digitpa.www.protocollo.EsitoConsegnaDocument ricezioneEsiti
                (
                  it.gov.digitpa.www.protocollo.NotificaDocument notifica
                 )
            ;
        
         }
    