/*
 * XML Type:  TitoloDocumento
 * Namespace: http://www.digitPa.gov.it/protocollo/
 * Java type: it.gov.digitpa.www.protocollo.TitoloDocumento
 *
 * Automatically generated - do not modify.
 */
package it.gov.digitpa.www.protocollo.impl;
/**
 * An XML TitoloDocumento(@http://www.digitPa.gov.it/protocollo/).
 *
 * This is a complex type.
 */
public class TitoloDocumentoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements it.gov.digitpa.www.protocollo.TitoloDocumento
{
    
    public TitoloDocumentoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
