
/**
 * ProtocolloServiceSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.6  Built on : Aug 30, 2011 (10:00:16 CEST)
 */
    package it.gov.digitpa.www.protocollo;
    /**
     *  ProtocolloServiceSkeleton java skeleton for the axisService
     */
    public class ProtocolloServiceSkeleton implements ProtocolloServiceSkeletonInterface{
        
         
        /**
         * Auto generated method signature
         * 
                                     * @param segnaturaEnvelope11
         */
        
                 public it.gov.digitpa.www.protocollo.EsitoConsegnaDocument consegna
                  (
                  it.gov.digitpa.www.protocollo.SegnaturaEnvelopeDocument segnaturaEnvelope11
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#consegna");
        }
     
    }
    