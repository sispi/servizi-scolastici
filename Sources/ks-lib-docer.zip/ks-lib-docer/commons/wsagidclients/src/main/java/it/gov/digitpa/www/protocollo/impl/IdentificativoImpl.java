/*
 * XML Type:  Identificativo
 * Namespace: http://www.digitPa.gov.it/protocollo/
 * Java type: it.gov.digitpa.www.protocollo.Identificativo
 *
 * Automatically generated - do not modify.
 */
package it.gov.digitpa.www.protocollo.impl;
/**
 * An XML Identificativo(@http://www.digitPa.gov.it/protocollo/).
 *
 * This is a complex type.
 */
public class IdentificativoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements it.gov.digitpa.www.protocollo.Identificativo
{
    
    public IdentificativoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
