/*
 * XML Type:  InterventoOperatore
 * Namespace: http://www.digitPa.gov.it/protocollo/
 * Java type: it.gov.digitpa.www.protocollo.InterventoOperatore
 *
 * Automatically generated - do not modify.
 */
package it.gov.digitpa.www.protocollo.impl;
/**
 * An XML InterventoOperatore(@http://www.digitPa.gov.it/protocollo/).
 *
 * This is a complex type.
 */
public class InterventoOperatoreImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements it.gov.digitpa.www.protocollo.InterventoOperatore
{
    
    public InterventoOperatoreImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
