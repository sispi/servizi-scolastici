/*
 * XML Type:  Denominazione
 * Namespace: http://www.digitPa.gov.it/protocollo/
 * Java type: it.gov.digitpa.www.protocollo.Denominazione
 *
 * Automatically generated - do not modify.
 */
package it.gov.digitpa.www.protocollo.impl;
/**
 * An XML Denominazione(@http://www.digitPa.gov.it/protocollo/).
 *
 * This is a complex type.
 */
public class DenominazioneImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements it.gov.digitpa.www.protocollo.Denominazione
{
    
    public DenominazioneImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
