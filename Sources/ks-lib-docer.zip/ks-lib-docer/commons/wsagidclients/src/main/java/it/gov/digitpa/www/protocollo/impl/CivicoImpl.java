/*
 * XML Type:  Civico
 * Namespace: http://www.digitPa.gov.it/protocollo/
 * Java type: it.gov.digitpa.www.protocollo.Civico
 *
 * Automatically generated - do not modify.
 */
package it.gov.digitpa.www.protocollo.impl;
/**
 * An XML Civico(@http://www.digitPa.gov.it/protocollo/).
 *
 * This is a complex type.
 */
public class CivicoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements it.gov.digitpa.www.protocollo.Civico
{
    
    public CivicoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
