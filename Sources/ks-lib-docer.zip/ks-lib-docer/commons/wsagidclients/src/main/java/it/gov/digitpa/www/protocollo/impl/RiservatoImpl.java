/*
 * XML Type:  Riservato
 * Namespace: http://www.digitPa.gov.it/protocollo/
 * Java type: it.gov.digitpa.www.protocollo.Riservato
 *
 * Automatically generated - do not modify.
 */
package it.gov.digitpa.www.protocollo.impl;
/**
 * An XML Riservato(@http://www.digitPa.gov.it/protocollo/).
 *
 * This is a complex type.
 */
public class RiservatoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements it.gov.digitpa.www.protocollo.Riservato
{
    
    public RiservatoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
