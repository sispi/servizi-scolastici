package docer.utils;

import java.io.File;

public class FileConverterHelper {
    public static void convert(File input, File output) {
        throw new UnsupportedOperationException();
    }
}
