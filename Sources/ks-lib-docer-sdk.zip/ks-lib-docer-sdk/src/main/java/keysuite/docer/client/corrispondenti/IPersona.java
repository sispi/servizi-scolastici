package keysuite.docer.client.corrispondenti;

public interface IPersona extends ICorrispondente {
    String getIdentificativo();
    String getDenominazione();
}
