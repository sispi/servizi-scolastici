package keysuite.docer.client.verificafirma;

public class Timestamp extends Token {
}
