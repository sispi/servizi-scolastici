package keysuite.docer.client.corrispondenti;

public interface IPersonaGiuridica extends IPersona, ICorrispondente {
    String getTipoPersonaGiuridica();
}
