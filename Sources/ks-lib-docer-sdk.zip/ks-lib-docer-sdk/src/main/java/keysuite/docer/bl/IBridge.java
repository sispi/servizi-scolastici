package keysuite.docer.bl;

public interface IBridge {
    //void bridge(String prefix, HttpServletRequest request, HttpServletResponse response);
}
