package keysuite.docer.client;

public abstract class Actor extends DocerBean implements IActor {
}
