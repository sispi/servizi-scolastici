@javax.xml.bind.annotation.XmlSchema(namespace = "http://pmPay.it/ws/authPA/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package it.filippetti.ks.api.payment.pmpay.authpa;
