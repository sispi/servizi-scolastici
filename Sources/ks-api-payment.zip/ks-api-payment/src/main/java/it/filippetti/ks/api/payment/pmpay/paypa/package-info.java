@javax.xml.bind.annotation.XmlSchema(namespace = "http://pmpay.it/ws/payPA/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package it.filippetti.ks.api.payment.pmpay.paypa;
