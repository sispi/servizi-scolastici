@javax.xml.bind.annotation.XmlSchema(namespace = "http://services.api.web.cg.igfs.apps.netsw.it/")
package it.filippetti.ks.api.payment.bnl.pay;
