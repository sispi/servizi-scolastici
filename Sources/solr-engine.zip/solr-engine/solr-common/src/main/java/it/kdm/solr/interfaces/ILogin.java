package it.kdm.solr.interfaces;


public interface ILogin extends IProvider {
	public boolean loginSSO(String userId) ;
}
