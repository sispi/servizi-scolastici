Jar da aggiungere:

ddlutils 1.3.3
commons-beanutils 1.7.0
dbexport-3.3.0...

Conf:
dbexport.xml
ddl/solr

solrconfig.xml:
aggiungere handler per /dbexport
