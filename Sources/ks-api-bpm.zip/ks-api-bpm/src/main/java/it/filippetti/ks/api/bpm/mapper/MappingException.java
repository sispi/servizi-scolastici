/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.filippetti.ks.api.bpm.mapper;

/**
 *
 * @author marco.mazzocchetti
 */
public class MappingException extends RuntimeException {

    public MappingException(Throwable cause) {
        super(cause);
    }
    
}
