export class MyPractices{
    constructor(notSended, toBeIntegrated, completed, inProgressAtTheInstitution){
        this.notSended = notSended;
        this.toBeIntegrated = toBeIntegrated;
        this.inProgressAtTheInstitution = inProgressAtTheInstitution;
    }
}