pkill -e -f ks-web-desktop

ulimit -Hn 20000
ulimit -Sn 20000

rm -rf output.log

java -Dlogging.level.root=WARN -jar ks-web-desktop-1.0.jar --spring.config.location=config/ &> output.log &

