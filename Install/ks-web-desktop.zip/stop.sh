pkill -e -f ks-web-desktop

