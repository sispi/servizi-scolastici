pkill -e -f ks-api-sispi

ulimit -Hn 20000
ulimit -Sn 20000

rm -rf output.log

java -jar ks-api-sispi-1.0.jar --spring.config.location=config/application.yml &> output.log &

