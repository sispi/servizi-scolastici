pkill -e -f ks-api-sispi

