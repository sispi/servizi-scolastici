pkill -e -f ks-api-portal

