pkill -e -f ks-spa-form
ulimit -Hn 20000
ulimit -Sn 20000

rm -rf output.log

java -jar ks-spa-form-1.0.jar --spring.config.location=config/application.yml &> output.log &

