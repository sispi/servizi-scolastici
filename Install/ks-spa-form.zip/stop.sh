pkill -e -f ks-spa-form

