pkill -e -f ks-api-payment

